+++
title = '本地HugoSite服务部署'
date = 2026-01-13T15:55:40+08:00
draft = true
image = "background.png"
categories = [
    "Hugo",
    "学习笔记",
]
+++

# 主要借鉴up主[Letere-莱特雷](https://space.bilibili.com/402971365)

## 下载Hugo

推荐使用老版本[Hugo](https://github.com/gohugoio/hugo/releases/tag/v0.136.0)比较稳定，一般电脑选择这个windows-amd64进行下载即可

![1768294775197](image/index/1768294775197.png)

## Hugo配置

### 解压Hugo，并在Hugo所在的文件夹的地址栏输入cmd，按下Enter进入命令行模式

![1768294921643](image/index/1768294921643.png)

### 使用命令 `hugo new site xxx `创建Hugo site基础文件

![1768294981352](image/index/1768294981352.png)

### 复制一个hugo.exe放入xxx文件夹中

### 使用命令 `cd xxx`进入xxx文件夹中

### `hugo server -D` 启动该服务器

![1768295537491](image/index/1768295537491.png)

## 选择喜欢的Hugo Theme

[Hugo Theme官网](https://themes.gohugo.io/)， 我这里以[Stack](https://themes.gohugo.io/themes/hugo-theme-stack/)为例子

![1768297600243](image/index/1768297600243.png)

### 点击Download进入Github，点击左上的Tag选择版本（推荐高版本）

![1768294746510](image/index/1768294746510.png)

### 下载这个压缩包

![1768294824423](image/index/1768294824423.png)

### 解压Stack Theme压缩包，并且去掉后面的版本号

![1768295152777](image/index/1768295152777.png)

### 将文件放到Hugo创建的xxx文件夹里面的themes中

![1768295611477](image/index/1768295611477.png)

### 进入hugo-theme-stack/exampleSite文件夹复制图中1，2文件

![1768295873559](image/index/1768295873559.png)

### 将1，2文件粘贴到xxx文件中

![1768295945774](image/index/1768295945774.png)

* 进入content/post 中 删除rich-content文件夹
  ![1768296324161](image/index/1768296324161.png)

### 回到xxx文件夹进入命令行模式，使用 `hugo server -D` 启动服务器

![1768296400296](image/index/1768296400296.png)

# 恭喜你已经成功部署了一个自己本地的hugo服务
